import Footer from "@/components/footer/footers";
import Navbar from "@/components/navbar";
import Image from "next/image";
import React from "react";
import notFoundSvg from '@/assets/images/404-computer.svg'

export default function NotFound(){
    return (
        <>
            <Navbar/>
            <section className="bg-white dark:bg-gray-900">
                <div className="py-2 px-4 mx-auto lg:py-4 lg:px-6 flex justify-center">
                    <div className="mx-auto max-w-screen-sm text-center flex flex-col">
                        <Image src={notFoundSvg} alt="" className="self-center"/>
                        {/* <h1 className="mb-4 text-7xl tracking-tight font-extrabold lg:text-9xl text-primary-600 dark:text-primary-500">404</h1> */}
                        <p className="mb-4 text-3xl tracking-tight font-bold text-gray-900 md:text-4xl dark:text-white">Something's missing.</p>
                        <p className="mb-4 text-lg font-light text-gray-500 dark:text-gray-400">Sorry, we can't find that page. You'll find lots to explore on the home page. </p>
                        <a href="#" className="inline-flex text-white bg-primary-600 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:focus:ring-primary-900 my-4">Back to Homepage</a>
                    </div>   
                </div>
            </section>
            <Footer/>
        </>
    );
}